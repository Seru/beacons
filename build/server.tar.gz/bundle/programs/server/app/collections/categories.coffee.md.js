(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Categories;

this.Categories = Categories = new Meteor.Collection('category');

Categories.attachSchema(new SimpleSchema({
  name: {
    type: String,
    index: true,
    min: 3,
    max: 100
  },
  description: {
    type: String
  }
}));

Categories.helpers;

Meteor.methods;

})();

//# sourceMappingURL=categories.coffee.md.js.map

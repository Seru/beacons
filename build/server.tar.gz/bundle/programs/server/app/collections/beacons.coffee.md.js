(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Beacons;

this.Beacons = Beacons = new Meteor.Collection('beacon');

Beacons.attachSchema(new SimpleSchema({
  id: {
    type: String,
    index: true
  },
  description: {
    type: Object,
    blackbox: true
  },
  name: {
    type: String
  },
  abbr: {
    type: String,
    max: 10
  }
}));

Beacons.allow({
  insert: function(userId, doc) {
    return true;
  },
  update: function(userId, docs, fields, modifier) {
    return true;
  },
  remove: function(userId, doc) {
    return true;
  }
});

Beacons.helpers({
  url: function() {
    return "/blog/" + this.slug;
  }
});

Meteor.methods;

})();

//# sourceMappingURL=beacons.coffee.md.js.map

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Exercises;

this.Exercises = Exercises = new Meteor.Collection('exercise');

Exercises.attachSchema(new SimpleSchema({
  name: {
    type: String,
    index: true,
    min: 3,
    max: 100
  },
  moodle: {
    type: Object,
    blackbox: true
  },
  category: {
    type: String
  },
  dependencies: {
    type: [String]
  },
  beacon: {
    type: String
  },
  createdAt: {
    type: Date,
    defaultValue: new Date()
  }
}));

Exercises.helpers;

Meteor.methods;

})();

//# sourceMappingURL=exercises.coffee.md.js.map

(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('publishedExercises', function() {
  return Exercises.find();
});

Meteor.publish('publishedCategories', function() {
  return Categories.find();
});

})();

//# sourceMappingURL=publications.coffee.md.js.map

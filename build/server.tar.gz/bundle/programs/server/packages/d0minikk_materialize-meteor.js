(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['d0minikk:materialize-meteor'] = {};

})();

//# sourceMappingURL=d0minikk_materialize-meteor.js.map
